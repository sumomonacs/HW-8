import java.io.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class JsonReader {
  public static void main(String[] args) {
    String filePath = "D:\\document-new semster\\CS-5004\\hw8\\align_quest_game_elements.json";
    StringBuilder jsonContent = new StringBuilder();

    try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
      String line;
      while ((line = br.readLine()) != null) {
        jsonContent.append(line.trim());  // line triming
      }
    } catch (IOException e) {
      e.printStackTrace();
    }

    // change the
    String jsonString = jsonContent.toString();

    // extract jsonvalue
    String gameName = extractJsonValue(jsonString, "name");
    String gameVersion = extractJsonValue(jsonString, "version");

    // printout value
    System.out.println("Game Name: " + gameName);
    System.out.println("Game Version: " + gameVersion);
  }

  //manually find the key pattern
  private static String extractJsonValue(String json, String key) {
    String keyPattern = "\"" + key + "\"\\s*:\\s*\"(.*?)\"";
    Pattern pattern = Pattern.compile(keyPattern);
    Matcher matcher = pattern.matcher(json);

    if (matcher.find()) {
      return matcher.group(1);
    } else {
      return "Not Found";
    }
  }
}
