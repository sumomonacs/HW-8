import java.util.List;

public class Room {
    public String room_name;
    public String room_number;
    public String description;
    public String N;
    public String S;
    public String E;
    public String W;
    public List<Puzzle> puzzles; //
    public List<Monster> monsters;
    public List<Item> item;
    public String picture;


}
