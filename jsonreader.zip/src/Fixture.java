
public class Fixture {
  public String name;
  public int weight;
  public String puzzle;
  public String states;
  public String description;
  public String picture;
}