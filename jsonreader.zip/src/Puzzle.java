
public class Puzzle {
  public String name;
  public boolean active;
  public boolean affects_target;
  public boolean affects_player;
  public String solution;
  public int value;
  public String description;
  public String effects;
  public String target;
  public String picture;
}