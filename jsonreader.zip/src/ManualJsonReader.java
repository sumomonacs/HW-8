import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ManualJsonReader {
  public static void main(String[] args) {
    String filePath = "D:\\document-new semster\\CS-5004\\hw8\\align_quest_game_elements.json";
    List<Item> itemList = new ArrayList<>();
    boolean inItemsSection = false;

    try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
      String line;
      Item currentItem = null;

      while ((line = br.readLine()) != null) {
        line = line.trim();

        if (line.startsWith("\"items\"")) {
          inItemsSection = true;
          continue;
        }

        if (inItemsSection && line.startsWith("]")) {
          break;
        }

        if (inItemsSection) {
          if (line.startsWith("{")) {
            currentItem = new Item();
          } else if (line.startsWith("\"name\"")) {
            currentItem.name = extractValue(line);
          } else if (line.startsWith("\"weight\"")) {
            currentItem.weight = Integer.parseInt(extractValue(line));
          } else if (line.startsWith("\"max_uses\"")) {
            currentItem.max_uses = Integer.parseInt(extractValue(line));
          } else if (line.startsWith("\"uses_remaining\"")) {
            currentItem.uses_remaining = Integer.parseInt(extractValue(line));
          } else if (line.startsWith("\"value\"")) {
            currentItem.value = Integer.parseInt(extractValue(line));
          } else if (line.startsWith("\"when_used\"")) {
            currentItem.when_used = extractValue(line);
          } else if (line.startsWith("\"description\"")) {
            currentItem.description = extractValue(line);
          } else if (line.startsWith("\"picture\"")) {
            currentItem.picture = extractValue(line);
          } else if (line.startsWith("}")) {
            itemList.add(currentItem);
          }
        }
      }

      for (Item item : itemList) {
        System.out.println(item);
      }

    } catch (IOException e) {
      e.printStackTrace();
    }
  }


  private static String extractValue(String jsonLine) {
    int start = jsonLine.indexOf(":") + 1;
    String value = jsonLine.substring(start).trim();


    if (value.startsWith("\"")) {
      value = value.substring(1, value.length() - 1);
    }


    if (value.endsWith(",")) {
      value = value.substring(0, value.length() - 1);
    }

    return value;
  }
}